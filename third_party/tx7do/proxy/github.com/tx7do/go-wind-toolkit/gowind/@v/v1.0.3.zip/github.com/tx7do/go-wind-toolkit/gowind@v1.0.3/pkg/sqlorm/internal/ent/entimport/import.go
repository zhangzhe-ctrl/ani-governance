package entimport

import (
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"

	"ariga.io/atlas/sql/schema"

	"entgo.io/contrib/schemast"
	"entgo.io/ent"
	"entgo.io/ent/dialect"
	"entgo.io/ent/dialect/entsql"
	entschema "entgo.io/ent/schema"
	"entgo.io/ent/schema/edge"

	"github.com/go-openapi/inflect"

	"github.com/tx7do/go-wind-toolkit/gowind/internal/schemasource"
)

// NewImport calls the relevant data source importer based on a given dialect.
func NewImport(opts ...ImportOption) (SchemaImporter, error) {
	var (
		si  SchemaImporter
		err error
	)
	i := &ImportOptions{}
	for _, apply := range opts {
		apply(i)
	}

	switch i.driver.Dialect {
	case dialect.MySQL:
		si, err = NewMySQL(i)
		if err != nil {
			return nil, err
		}

	case dialect.Postgres:
		si, err = NewPostgreSQL(i)
		if err != nil {
			return nil, err
		}

	case "text":
		si, err = NewText(i)
		if err != nil {
			return nil, err
		}

	default:
		return nil, fmt.Errorf("entimport: unsupported dialect %q", i.driver.Dialect)
	}

	return si, err
}

// WriteSchema receives a list of mutators, and writes an ent schema to a given location in the file system.
func WriteSchema(mutations []schemast.Mutator, opts ...ImportOption) error {
	i := &ImportOptions{}
	for _, apply := range opts {
		apply(i)
	}
	if err := os.MkdirAll(i.schemaPath, 0o755); err != nil {
		return err
	}
	ctx, err := loadSchemaContext(i.schemaPath)
	if err != nil {
		return err
	}
	if err = schemast.Mutate(ctx, mutations...); err != nil {
		return err
	}
	if err = ctx.Print(i.schemaPath, schemast.Header(header)); err != nil {
		return err
	}
	return formatSchemaFiles(i.schemaPath)
}

// loadSchemaContext 在 schema 目录内加载 schemast 上下文。
// schemast.Load 内部的 go/packages 不设置 Dir,以进程 CWD 运行 go list:
// GUI 进程(macOS 从 Dock/Finder 启动时 CWD 为 /)不在任何 Go module 内,
// go list 以 exit 1 + 空 stdout 失败,go/packages 驱动对这种失败无兜底分支,
// 返回 0 个包,schemast.Load 便报 "missing package information"(issue #13)。
// 因此临时把 CWD 切到 schema 目录——它必位于用户项目的 module 内——再加载,
// 结束后恢复原 CWD。
func loadSchemaContext(schemaPath string) (*schemast.Context, error) {
	absPath, err := filepath.Abs(schemaPath)
	if err != nil {
		return nil, err
	}
	origWd, err := os.Getwd()
	if err != nil {
		origWd = ""
	}
	if err = os.Chdir(absPath); err != nil {
		return nil, fmt.Errorf("entimport: chdir to schema dir failed: %w", err)
	}
	defer func() {
		if origWd != "" {
			_ = os.Chdir(origWd)
		}
	}()

	ctx, err := schemast.Load(absPath)
	if err != nil {
		if strings.Contains(err.Error(), "missing package information") {
			return nil, fmt.Errorf("entimport: %w (schema dir is not inside a Go module; run `go mod init` in the target project first)", err)
		}
		return nil, err
	}
	return ctx, nil
}

// entEdge creates an edge based on the given params and direction.
func entEdge(nodeName, nodeType string, currentNode *schemast.UpsertSchema, dir edgeDir, opts relOptions) (e ent.Edge) {
	var desc *edge.Descriptor
	switch dir {
	case to:
		e = edge.To(nodeName, ent.Schema.Type)
		desc = e.Descriptor()
		if opts.uniqueEdgeToChild {
			desc.Unique = true
			desc.Name = inflect.Singularize(nodeName)
		}
		if opts.recursive {
			desc.Name = "child_" + desc.Name
		}
	case from:
		e = edge.From(nodeName, ent.Schema.Type)
		desc = e.Descriptor()
		if opts.uniqueEdgeFromParent {
			desc.Unique = true
			desc.Name = inflect.Singularize(nodeName)
		}
		if opts.edgeField != "" {
			setEdgeField(e, opts, currentNode)
		}
		// RefName describes which entEdge of the Parent Node we're referencing
		// because there can be multiple references from one node to another.
		refName := opts.refName
		if opts.uniqueEdgeToChild {
			refName = inflect.Singularize(refName)
		}
		desc.RefName = refName
		if opts.recursive {
			desc.Name = "parent_" + desc.Name
			desc.RefName = "child_" + desc.RefName
		}

	default:
	}

	if desc != nil {
		desc.Type = nodeType
	}

	return e
}

// setEdgeField is a function to properly name edge fields.
func setEdgeField(e ent.Edge, opts relOptions, childNode *schemast.UpsertSchema) {
	edgeField := opts.edgeField
	// rename the field in case the edge and the field have the same name
	if e.Descriptor().Name == edgeField {
		edgeField += "_id"
		for _, f := range childNode.Fields {
			if f.Descriptor().Name == opts.edgeField {
				f.Descriptor().Name = edgeField
			}
		}
	}
	e.Descriptor().Field = edgeField
}

// upsertRelation takes 2 nodes and created the edges between them.
func upsertRelation(nodeA *schemast.UpsertSchema, nodeB *schemast.UpsertSchema, opts relOptions) {
	tableA := tableName(nodeA.Name)
	tableB := tableName(nodeB.Name)
	fromA := entEdge(tableA, nodeA.Name, nodeB, from, opts)
	toB := entEdge(tableB, nodeB.Name, nodeA, to, opts)
	nodeA.Edges = append(nodeA.Edges, toB)
	nodeB.Edges = append(nodeB.Edges, fromA)
}

// upsertManyToMany handles the creation of M2M relations.
func upsertManyToMany(mutations map[string]schemast.Mutator, table *schema.Table) error {
	tableA := table.ForeignKeys[0].RefTable
	tableB := table.ForeignKeys[1].RefTable
	var opts relOptions
	if tableA.Name == tableB.Name {
		opts.recursive = true
	}
	nodeA, ok := mutations[tableA.Name].(*schemast.UpsertSchema)
	if !ok {
		return joinTableErr
	}
	nodeB, ok := mutations[tableB.Name].(*schemast.UpsertSchema)
	if !ok {
		return joinTableErr
	}
	opts.refName = tableName(nodeB.Name)
	upsertRelation(nodeA, nodeB, opts)
	return nil
}

func typeName(tableName string) string {
	return inflect.Camelize(inflect.Singularize(tableName))
}

func tableName(typeName string) string {
	return inflect.Underscore(inflect.Pluralize(typeName))
}

// resolvePrimaryKey returns the primary key as an ent field for a given table.
func resolvePrimaryKey(field fieldFunc, table *schema.Table) (f ent.Field, err error) {
	if table.PrimaryKey == nil {
		return nil, fmt.Errorf("entimport: missing primary key (table: %v)", table.Name)
	}
	if len(table.PrimaryKey.Parts) != 1 {
		return nil, fmt.Errorf("entimport: invalid primary key, single part key must be present (table: %v, got: %v parts)", table.Name, len(table.PrimaryKey.Parts))
	}
	if f, err = field(table.PrimaryKey.Parts[0].C); err != nil {
		return nil, err
	}
	if d := f.Descriptor(); d.Name != "id" {
		d.StorageKey = d.Name
		d.Name = "id"
	}
	return f, nil
}

// upsertNode handles the creation of a node from a given table.
func upsertNode(field fieldFunc, table *schema.Table) (*schemast.UpsertSchema, error) {
	upsert := &schemast.UpsertSchema{
		Name: typeName(table.Name),
	}

	//fmt.Println("UpsertSchema", table.Name, table.Attrs)

	withComment := false
	comment := ""
	charset := ""
	collation := ""
	for _, attr := range table.Attrs {
		switch a := attr.(type) {
		case *schema.Comment:
			comment = a.Text
			withComment = true
			//fmt.Println("schema.Comment", comment)

		case *schema.Charset:
			//fmt.Println("schema.Charset", a.V)
			charset = a.V

		case *schema.Collation:
			//fmt.Println("schema.Collation", a.V)
			collation = a.V
		}
	}

	annotation := entsql.Annotation{}

	if withComment {
		annotation.WithComments = &withComment
	}
	if charset != "" {
		annotation.Charset = charset
	}
	if collation != "" {
		annotation.Collation = collation
	}
	// 实际表名与 ent 默认表名(类型名复数化)不一致时,注解记录**实际**表名,
	// 保证生成的 schema 指向内省到的真实表;一致时该字段留空。
	if tableName(table.Name) != table.Name {
		annotation.Table = table.Name
	}

	// 注解无任何内容时不设置 Annotations,序列化为 `return nil`
	// (与 ent 官方 entimport 行为一致)。
	if annotation.Table != "" || annotation.Charset != "" ||
		annotation.Collation != "" || annotation.WithComments != nil {
		upsert.Annotations = []entschema.Annotation{
			annotation,
		}
	}

	if comment != "" {
		//upsert.Annotations = append(upsert.Annotations, entschema.Comment(comment))
	}

	fields := make(map[string]ent.Field, len(upsert.Fields))
	for _, f := range upsert.Fields {
		fields[f.Descriptor().StorageKey] = f
	}
	pk, err := resolvePrimaryKey(field, table)
	if err != nil {
		return nil, err
	}
	if _, ok := fields[pk.Descriptor().StorageKey]; !ok {
		fields[pk.Descriptor().StorageKey] = pk
		upsert.Fields = append(upsert.Fields, pk)
	}
	for _, column := range table.Columns {
		if table.PrimaryKey != nil &&
			len(table.PrimaryKey.Parts) != 0 &&
			table.PrimaryKey.Parts[0].C.Name == column.Name {
			continue
		}
		fld, err := field(column)
		if err != nil {
			return nil, err
		}
		if _, ok := fields[column.Name]; !ok {
			fields[column.Name] = fld
			upsert.Fields = append(upsert.Fields, fld)
		}
	}
	for _, index := range table.Indexes {
		if index.Unique && len(index.Parts) == 1 {
			fields[index.Parts[0].C.Name].Descriptor().Unique = true
		}
	}
	for _, fk := range table.ForeignKeys {
		for _, column := range fk.Columns {
			// FK / Reference column
			fld, ok := fields[column.Name]
			if !ok {
				return nil, fmt.Errorf("foreign key for column: %q doesn't exist in referenced table", column.Name)
			}
			fld.Descriptor().Optional = true
		}
	}
	return upsert, err
}

// applyColumnAttributes adds column attributes to a given ent field.
func applyColumnAttributes(f ent.Field, col *schema.Column) {
	desc := f.Descriptor()
	desc.Optional = col.Type.Null
	for _, attr := range col.Attrs {
		if a, ok := attr.(*schema.Comment); ok {
			desc.Comment = a.Text
		}
	}
}

// schemaMutations is in charge of creating all the schema mutations needed for an ent schema.
func schemaMutations(field fieldFunc, tables []*schema.Table) ([]schemast.Mutator, error) {
	mutations := make(map[string]schemast.Mutator)
	joinTables := make(map[string]*schema.Table)
	for _, table := range tables {
		if schemasource.IsJoinTable(table) {
			joinTables[table.Name] = table
			continue
		}
		node, err := upsertNode(field, table)
		if err != nil {
			return nil, fmt.Errorf("entimport: issue with table %v: %w", table.Name, err)
		}
		mutations[table.Name] = node
	}

	for _, table := range tables {
		if t, ok := joinTables[table.Name]; ok {
			err := upsertManyToMany(mutations, t)
			if err != nil {
				return nil, err
			}
			continue
		}
		upsertOneToX(mutations, table)
	}

	ml := make([]schemast.Mutator, 0, len(mutations))
	for _, mutator := range mutations {
		ml = append(ml, mutator)
	}
	return ml, nil
}

// O2O Two Types - Child Table has a unique reference (FK) to Parent table
// O2O Same Type - Child Table has a unique reference (FK) to Parent table (itself)
// O2M (The "Many" side, keeps a reference to the "One" side).
// O2M Two Types - Parent has a non-unique reference to Child, and Child has a unique back-reference to Parent
// O2M Same Type - Parent has a non-unique reference to Child, and Child doesn't have a back-reference to Parent.
func upsertOneToX(mutations map[string]schemast.Mutator, table *schema.Table) {
	if table.ForeignKeys == nil {
		return
	}
	idxes := make(map[string]*schema.Index)
	for _, idx := range table.Indexes {
		if len(idx.Parts) != 1 {
			continue
		}
		idxes[idx.Parts[0].C.Name] = idx
	}
	for _, fk := range table.ForeignKeys {
		if len(fk.Columns) != 1 {
			continue
		}
		parent := fk.RefTable
		child := table
		colName := fk.Columns[0].Name
		opts := relOptions{
			uniqueEdgeFromParent: true,
			refName:              tableName(child.Name),
			edgeField:            colName,
		}
		if child.Name == parent.Name {
			opts.recursive = true
		}
		idx, ok := idxes[colName]
		if ok && idx.Unique {
			opts.uniqueEdgeToChild = true
		}
		// If at least one table in the relation does not exist, there is no point to create it.
		parentNode, ok := mutations[parent.Name].(*schemast.UpsertSchema)
		if !ok {
			return
		}
		childNode, ok := mutations[child.Name].(*schemast.UpsertSchema)
		if !ok {
			return
		}
		upsertRelation(parentNode, childNode, opts)
	}
}

// formatSchemaFiles 后处理 schema 文件：
// 1. 修正 goimports 可能选错的 import（gorm.io/gen/field → entgo.io/ent/schema/field）
// 2. 将 Fields() 方法中的字段断行显示
func formatSchemaFiles(schemaPath string) error {
	entries, err := os.ReadDir(schemaPath)
	if err != nil {
		return err
	}
	for _, entry := range entries {
		if entry.IsDir() || !strings.HasSuffix(entry.Name(), ".go") {
			continue
		}
		filePath := filepath.Join(schemaPath, entry.Name())
		content, err := os.ReadFile(filePath)
		if err != nil {
			return err
		}

		// 修正 goimports 可能选错的 import
		fixed := fixFieldImport(string(content))

		formatted := formatFieldsContent(fixed)
		if formatted != string(content) {
			if err := os.WriteFile(filePath, []byte(formatted), 0644); err != nil {
				return err
			}
		}
	}
	return nil
}

// fixFieldImport 修正 goimports 可能将 entgo.io/ent/schema/field 误解析为 gorm.io/gen/field 的问题
func fixFieldImport(content string) string {
	return strings.ReplaceAll(content,
		"\"gorm.io/gen/field\"",
		"\"entgo.io/ent/schema/field\"",
	)
}

// fieldListRe 匹配 return []ent.Field{...}
var fieldListRe = regexp.MustCompile(`(?s)(\treturn \[\]ent\.Field\{)(.+?)(\}\n)`)

// formatFieldsContent 将 []ent.Field{...} 中的字段按行断开
func formatFieldsContent(content string) string {
	return fieldListRe.ReplaceAllStringFunc(content, func(match string) string {
		sub := fieldListRe.FindStringSubmatch(match)
		if len(sub) < 4 {
			return match
		}
		prefix := sub[1] // "\treturn []ent.Field{"
		inner := sub[2]  // "field.Int(\"id\"), field.String(\"name\")"
		suffix := sub[3] // "}\n"

		fields := splitTopLevelFields(inner)
		if len(fields) <= 1 {
			return match // 单个字段不需要断行
		}

		var sb strings.Builder
		sb.WriteString(prefix)
		sb.WriteByte('\n')
		for _, f := range fields {
			sb.WriteString("\t\t")
			sb.WriteString(strings.TrimSpace(f))
			sb.WriteString(",\n")
		}
		sb.WriteString("\t")
		sb.WriteString(suffix)
		return sb.String()
	})
}

// splitTopLevelFields 按顶层逗号分割字段（忽略括号内的逗号）
func splitTopLevelFields(s string) []string {
	var fields []string
	var current strings.Builder
	depth := 0
	for _, ch := range s {
		switch ch {
		case '(', '[':
			depth++
			current.WriteRune(ch)
		case ')', ']':
			depth--
			current.WriteRune(ch)
		case ',':
			if depth == 0 {
				f := strings.TrimSpace(current.String())
				if f != "" {
					fields = append(fields, f)
				}
				current.Reset()
			} else {
				current.WriteRune(ch)
			}
		default:
			current.WriteRune(ch)
		}
	}
	if current.Len() > 0 {
		f := strings.TrimSpace(current.String())
		if f != "" {
			fields = append(fields, f)
		}
	}
	return fields
}
