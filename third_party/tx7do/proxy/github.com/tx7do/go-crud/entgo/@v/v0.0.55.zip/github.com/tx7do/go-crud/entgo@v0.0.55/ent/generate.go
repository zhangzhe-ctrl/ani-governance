package ent

//go:generate go run -mod=mod entgo.io/ent/cmd/ent generate --feature privacy --feature entql --feature sql/modifier --feature sql/upsert ./schema
