package transport

import "context"

// Server represents a single network server whose lifecycle is managed by the
// application. A typical implementation wraps a *grpc.Server,
// *http.Server, or similar, and blocks in Start until ctx is cancelled.
// See doc.go for the full contract and a minimal implementation example.
type Server interface {
	// Start begins accepting connections. It MUST block until ctx is
	// cancelled or an error occurs.
	Start(ctx context.Context) error
	// Stop performs a graceful shutdown. The provided ctx carries a deadline
	// that implementations should respect.
	Stop(ctx context.Context) error
	// Endpoint returns the actual network address the server is listening
	// on. For servers that bind to ":0" (OS-assigned port), this MUST
	// return the resolved address after [Start] begins accepting
	// connections, so callers can register it with a service registry.
	//
	// Implementations that have not yet started, or that listen on a
	// fixed address, may return the configured address immediately.
	Endpoint() string
}
